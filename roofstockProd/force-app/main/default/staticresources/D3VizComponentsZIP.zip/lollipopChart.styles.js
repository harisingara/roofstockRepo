let styles = {
//     /**
//      * @param themeSettings {ThemeSettings}
//      */
// 	getStyleSettingsVariants: (themeSettings) => {
//         const tokens = themeSettings.getTokens();
//         const palette = themeSettings.getPalette();

// 		return {
//             default: {
//                 padding: tokens.spacing.s1,
//                 borderColor: palette.primary[0],
//                 borderRadius: tokens.borderRadius.primary,
//             },
//             // You can define other style variants here
//             // red: {
//             //     borderColor: palette.error[0],
//             // } 
//         };
// 	},
// 	getStyles(t) { 
//         return {
//             "sample": {
//                 padding: t.padding,
//                 border: `1px solid ${ t.borderColor }`,
//                 borderRadius: t.borderRadius,
//                 width: "100%"
//             },
//             "button-input-container": {
//                 display: "grid",
//                 gridTemplateColumns: "1fr auto",
//                 gridColumnGap: "8px"
//             }
//         }
//     },
 }

skuidModule.exports = styles;