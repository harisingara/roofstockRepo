skuid.runtime.registerApi("v2", "pack/D3Viz/builders.js", function(skuid) {
	let bc = skuid.builder.core;
	let componentId = "D3Viz__lollipopChart";
	let $xml = skuid.utils.makeXMLDoc;

	bc.registerBuilder(new bc.Builder({
		id: componentId,
		name: "LollipopChart",
		icon: "sk-webicon-ink:people",
		description: "This component says Hello to someone",
		render(builderComponent) {
			return builderComponent.h("h2", [ "LollipopChart" ]);
		},
		defaultStateGenerator: function() {
			return $xml(`<${componentId}/>`);
		},
	}));
})