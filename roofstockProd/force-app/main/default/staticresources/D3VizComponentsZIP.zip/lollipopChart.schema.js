let schema = {
	attributes: {
        model: {
            type: "model",
            helptext: "Choose a Model to drive the Viz",
            label: "Model"
        },
        
        valuefield: {
            type: "string",
            helptext: "A number field",
            label: "Value Field"
        },

        categoryfield: {
            type: "string",
            helptext: "Category field",
            label: "Category field",
        }
    },
	nodes: {},
	properties: {},
};

skuidModule.exports = schema;